def hathet():
    for x in range(10,221):
        if x%6 == 0 and x%7 == 0:
            print("HatHét!")
        elif x%6 == 0:
            print("Hat!")
        elif x%7 == 0:
            print("Hét!")
        else:
            print(x)

hathet()


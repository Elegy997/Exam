class Calculation:
    def __init__(self, projekt, kesedelem):
        self.kotber = 0
        self.projekt = projekt
        self.kesedelem = kesedelem

    def szamolas(self):
        self.kotber = self.projekt * (self.kesedelem*0.05)
        self.kotber = int(self.kotber)
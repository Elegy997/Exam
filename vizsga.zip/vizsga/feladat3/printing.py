from calculation import Calculation
import datetime

class Printing:
    def __init__(self, cegnev, projekt, kesedelem):
        self.cegnev = cegnev
        self.projekt = projekt
        self.kesedelem = kesedelem

    def megkotberezlek(self):
        szamolos = Calculation(self.projekt, self.kesedelem)
        szamolos.szamolas()
        date = datetime.datetime.now().strftime("%Y.%m.%d.")
        f = open("savanya_gergo.txt", "w")
        f.write(f"Kötbér kimutatás")
        f.write(f"\n")
        f.write(f"Cég neve: {self.cegnev}")
        f.write(f"\n")
        f.write(f"Projekt értéke: {self.projekt} Ft")
        f.write(f"\n")
        f.write(f"Késedelmes napok száma: {self.kesedelem}")
        f.write(f"\n")
        f.write(f"Kötbér összege: {szamolos.kotber} Ft")
        f.write(f"\n")
        f.write(f"\n")
        f.write(date)
        f.close()
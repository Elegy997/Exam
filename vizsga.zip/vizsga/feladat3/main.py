from printing import Printing

cegnev = input("A cég neve: ")
projekt_ertek = input("A projekt értéke: ")
kesedelem = input("Késedelmes napok száma: ")

if projekt_ertek.isnumeric() == False or kesedelem.isnumeric() == False:
    print("Egész számot adj meg!")
else:
    projektInt = int(projekt_ertek)
    kesedelemInt = int(kesedelem)
    kotberezos = Printing(cegnev, projektInt, kesedelemInt)
    kotberezos.megkotberezlek()
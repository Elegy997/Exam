import random

life = 5
szam = random.randint(101,150)


def talalgatos_game(guessInt):
    global szam
    global life
    global jatekban_van
    if guessInt == szam:
        print("Egy találatos szelvény!")
        jatekban_van = False
    if guessInt < szam:
        print("Nagyobb")
        life -= 1
        if life < 1:
            print("0 találatos szelvény!")
            jatekban_van = False
    if guessInt > szam:
        print("Kisebb")
        life -= 1
        if life < 1:
            print("0 találatos szelvény!")
            jatekban_van = False

jatekban_van = True
while jatekban_van == True:
    guess = input("Találd ki a számot(101-150):")
    if guess.isnumeric() == False:
        print("Számot adj meg, -2 élet!")
        life -= 2
        if life < 1:
            print("0 találatos szelvény!")
            jatekban_van = False
    else:
        guessInt = int(guess)
        if guessInt < 101 or guessInt > 150:
            print("A szám nincs a megadott tartományban(101-150), -2 élet!")
            life -= 2
            if life < 1:
                print("0 találatos szelvény!")
                jatekban_van = False
        else:
            talalgatos_game(guessInt)


